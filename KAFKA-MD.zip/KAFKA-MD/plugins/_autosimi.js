import axios from "axios"

export async function before(m, {isROwner}) {
if (m.fromMe && !m.text) 
    return 
conn.simi = conn.simi ? conn.simi : false

if (isROwner && m.text == 'autosimi on') {
conn.simi = true
m.reply('autosimi aktif')
} if (isROwner && m.text == 'autosimi off') {
conn.simi = false
m.reply('autosimi aktif')
} if (conn.simi == true && m.text) {
try {

async function getMessage(yourMessage, langCode) {
            const res = await axios.post(
              "https://api.simsimi.vn/v2/simtalk",
              new URLSearchParams({
                text: yourMessage,
                lc: langCode,
              })
            );

            if (res.status > 200) throw new Error(res.data.success);

            return res.data.message;
          }
          let res = await getMessage(m.text, "id");
    await m.reply(`${res}`)
    } catch (e) {
    throw eror
    }
    }
}