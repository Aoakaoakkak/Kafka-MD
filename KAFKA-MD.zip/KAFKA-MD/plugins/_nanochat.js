import axios from "axios"

export async function before(m, {isROwner}) {
if (m.fromMe && !m.text) 
    return 
conn.nano = conn.nano ? conn.nano : false
let kii = 'KC-rc8OqPJSisIr';
if (isROwner && m.text == 'nanochat on') {
conn.nano = true
m.reply('nanochat aktif')
} if (isROwner && m.text == 'nanochat off') {
conn.nano = false
m.reply('nanochat aktif')
} if (conn.nano == true && m.text) {
try {
const { data } = await axios.get(`https://api.kiicodeit.me/ai/sindy?text=${m.text}&apikey=${kii}`)
    const msgai = data.result;
    await m.reply(`${msgai}`)
    } catch (e) {
    throw eror
    }
    }
}