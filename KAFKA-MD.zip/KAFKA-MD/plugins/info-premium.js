let handler = async (m, {
    conn,
    text,
    args,
    command,
    usedPrefix 
}) => {
const list = `⋄ ᴘʀᴇᴍɪᴜᴍ ᴋᴀꜰᴋᴀ - ᴍᴅ ⋄

[ 1 ] 1k/2hari 
[ 2 ] 3k/Minggu 
[ 3 ] 10k/bulan 
[ 4 ] 15k/bln + add ke grup pribadi (3hari)
[ 5 ] (25k permanen)
 
 Via Dana: not yet available 
 Qris: not yet available 
 Gopay: 08388198229
 Owner: wa.me/6288708220818
  
 *Note*: chat owner untuk pembelian premium, 
  beli = setuju 😃
`

conn.sendThumb(m.chat, list, 'https://telegra.ph/file/68f606e9d694706b433c1.png', m)
}
handler.help = handler.command = ['premium','prem']
handler.tags = ['main']
export default handler