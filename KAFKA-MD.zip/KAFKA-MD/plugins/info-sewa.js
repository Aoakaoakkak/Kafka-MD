let handler = async (m, {
    conn,
    text,
    args,
    command,
    usedPrefix 
}) => {
const list = `⋄ sᴇᴡᴀ ᴋᴀꜰᴋᴀ - ᴍᴅ ⋄

[ 1 ] 8k / Minggu 
[ 2 ] 27k / bulan 
[ 3 ]  55k / 2bulan
[ 4 ]  85k /2 bulan + premium (30 hari)

 Via Dana: not yet available 
 Qris: not yet available 
 Gopay: 08388198229
 
 Owner: wa.me/6288708220818
  
 *Note*: chat owner untuk sewa Bot
                   Bot selalu Ter Up To Date

 anda membeli = setuju 😃
`

conn.sendFile(m.chat, 'https://telegra.ph/file/68f606e9d694706b433c1.png', '', list, m)
}
handler.help = handler.command = ['sewa','sewabot']
handler.tags = ['main']
export default handler